/* =========================================================
   SMART STUDENT - SISTEMA COMPLETO (js/script.js)
========================================================= */

const STORAGE_ALUNOS = 'smart_student_alunos_v1';
const STORAGE_REGISTOS = 'smart_student_registos_v1';

const TURMAS_PADRAO = [
    'Electrónica',
    'Informática',
    'Construção Civil',
    'Mecânica'
];

const ALUNOS_INICIAIS = [
    { id: 101, numero: '001', nome: 'Ana Beatriz Silva', turma: 'Electrónica' },
    { id: 102, numero: '002', nome: 'Carlos Eduardo Mendes', turma: 'Electrónica' },
    { id: 103, numero: '003', nome: 'Mariana Costa', turma: 'Electrónica' },
    { id: 104, numero: '001', nome: 'João Pedro Alves', turma: 'Informática' },
    { id: 105, numero: '002', nome: 'Sofia Rodrigues', turma: 'Informática' },
    { id: 106, numero: '003', nome: 'Tiago Fernandes', turma: 'Informática' },
    { id: 107, numero: '001', nome: 'Lucas Martins', turma: 'Construção Civil' },
    { id: 108, numero: '002', nome: 'Helena Sousa', turma: 'Construção Civil' },
    { id: 109, numero: '001', nome: 'Rafael Gomes', turma: 'Mecânica' },
    { id: 110, numero: '002', nome: 'Beatriz Oliveira', turma: 'Mecânica' }
];

/* ------------------ FUNÇÕES DE ARMAZENAMENTO ------------------ */
function getAlunos() {
    try {
        const bruto = localStorage.getItem(STORAGE_ALUNOS);
        if (!bruto) {
            localStorage.setItem(STORAGE_ALUNOS, JSON.stringify(ALUNOS_INICIAIS));
            return [...ALUNOS_INICIAIS];
        }
        const parsed = JSON.parse(bruto);
        return Array.isArray(parsed) ? parsed : [...ALUNOS_INICIAIS];
    } catch (e) {
        console.error('Erro ao ler alunos:', e);
        return [...ALUNOS_INICIAIS];
    }
}

function setAlunos(lista) {
    localStorage.setItem(STORAGE_ALUNOS, JSON.stringify(lista));
}

function getRegistos() {
    try {
        const bruto = localStorage.getItem(STORAGE_REGISTOS);
        if (!bruto) return [];
        const parsed = JSON.parse(bruto);
        return Array.isArray(parsed) ? parsed : [];
    } catch (e) {
        console.error('Erro ao ler registos:', e);
        return [];
    }
}

function setRegistos(lista) {
    localStorage.setItem(STORAGE_REGISTOS, JSON.stringify(lista));
}

function formatDoisDigitos(valor) {
    const n = parseInt(valor, 10);
    if (isNaN(n)) return String(valor || '00');
    return String(Math.max(0, n)).padStart(2, '0');
}

function escaparTexto(texto) {
    const div = document.createElement('div');
    div.textContent = texto == null ? '' : String(texto);
    return div.innerHTML;
}

/* ------------------ INICIALIZAÇÃO GLOBAL ------------------ */
document.addEventListener('DOMContentLoaded', () => {
    corrigirLinksRelatorios();
    iniciarInteracoesPainel();

    if (document.querySelector('.pagina-turmas')) {
        iniciarPaginaTurmas();
    }

    if (document.querySelector('.pagina-presencas')) {
        iniciarPaginaPresencas();
    }

    if (document.querySelector('.pagina-relatorios')) {
        iniciarPaginaRelatorios();
    }
});

// Garante que qualquer link para "relatorios.html" vá para "relatorio.html"
function corrigirLinksRelatorios() {
    document.querySelectorAll('a[href="relatorios.html"]').forEach(link => {
        link.setAttribute('href', 'relatorio.html');
    });
}

// Permite clicar nos cartões de turma do painel para ir direto às presenças dessa turma
function iniciarInteracoesPainel() {
    const itensTurma = document.querySelectorAll('.turmas-resumo .turma-item');
    if (!itensTurma.length) return;

    itensTurma.forEach(item => {
        const titulo = item.querySelector('.turma-dados h4');
        const nomeTurma = titulo ? titulo.textContent.trim() : '';
        if (nomeTurma) {
            item.addEventListener('click', () => {
                window.location.href = `presencas.html?turma=${encodeURIComponent(nomeTurma)}`;
            });
        }
    });
}

/* =========================================================
   1. PÁGINA DE TURMAS (turmas.html)
========================================================= */
function iniciarPaginaTurmas() {
    const inputNome = document.getElementById('nome-aluno');
    const inputNumero = document.getElementById('numero-aluno');
    const selectTurmaCadastro = document.getElementById('turma-aluno');
    const btnCadastrar = document.querySelector('.botao-cadastrar-aluno');

    const inputPesquisa = document.getElementById('pesquisar-aluno');
    const selectFiltroTurma = document.getElementById('filtro-turma');
    const listaAlunosEl = document.querySelector('.lista-alunos');
    const btnAdicionarRapido = document.querySelector('.adicionar-aluno');
    const cardsTurma = document.querySelectorAll('.turma-card');

    function cadastrarNovoAluno() {
        const nome = inputNome ? inputNome.value.trim() : '';
        const numeroRaw = inputNumero ? inputNumero.value.trim() : '';
        const turma = selectTurmaCadastro ? selectTurmaCadastro.value.trim() : '';

        if (!nome) {
            alert('Por favor, introduza o nome completo do aluno.');
            if (inputNome) inputNome.focus();
            return;
        }

        if (!turma) {
            alert('Por favor, escolha a turma do aluno.');
            if (selectTurmaCadastro) selectTurmaCadastro.focus();
            return;
        }

        const alunosAtuais = getAlunos();
        const alunosDaTurma = alunosAtuais.filter(a => a.turma === turma);
        const proximoNumero = String(alunosDaTurma.length + 1).padStart(3, '0');
        const numeroFinal = numeroRaw || proximoNumero;

        const novoAluno = {
            id: Date.now() + Math.floor(Math.random() * 1000),
            numero: numeroFinal,
            nome,
            turma
        };

        alunosAtuais.push(novoAluno);
        setAlunos(alunosAtuais);

        if (inputNome) inputNome.value = '';
        if (inputNumero) inputNumero.value = '';
        if (selectTurmaCadastro) selectTurmaCadastro.value = '';

        if (selectFiltroTurma && selectFiltroTurma.value && selectFiltroTurma.value !== turma) {
            selectFiltroTurma.value = '';
        }

        renderizarAlunosTurmas();
        alert(`Aluno "${nome}" cadastrado na turma ${turma}!`);
    }

    function removerAlunoPorId(alunoId) {
        const alunosAtuais = getAlunos();
        const alunoAlvo = alunosAtuais.find(a => Number(a.id) === Number(alunoId));
        if (!alunoAlvo) return;

        const confirmar = confirm(`Deseja remover o aluno "${alunoAlvo.nome}" (${alunoAlvo.turma})?`);
        if (!confirmar) return;

        const novaLista = alunosAtuais.filter(a => Number(a.id) !== Number(alunoId));
        setAlunos(novaLista);
        renderizarAlunosTurmas();
    }

    function renderizarAlunosTurmas() {
        if (!listaAlunosEl) return;

        listaAlunosEl.querySelectorAll('.aluno-registo').forEach(el => el.remove());

        const termo = inputPesquisa ? inputPesquisa.value.trim().toLowerCase() : '';
        const turmaFiltro = selectFiltroTurma ? selectFiltroTurma.value.trim() : '';

        const alunosFiltrados = getAlunos().filter(aluno => {
            const matchTurma = !turmaFiltro || aluno.turma === turmaFiltro;
            const matchTexto = !termo ||
                String(aluno.nome).toLowerCase().includes(termo) ||
                String(aluno.numero).toLowerCase().includes(termo) ||
                String(aluno.turma).toLowerCase().includes(termo);
            return matchTurma && matchTexto;
        });

        if (alunosFiltrados.length === 0) {
            const vazio = document.createElement('div');
            vazio.className = 'aluno-registo';
            vazio.innerHTML = `
                <span>—</span>
                <strong>Nenhum aluno encontrado com os filtros atuais.</strong>
                <span>—</span>
            `;
            listaAlunosEl.appendChild(vazio);
            return;
        }

        alunosFiltrados.forEach(aluno => {
            const linha = document.createElement('div');
            linha.className = 'aluno-registo';
            linha.innerHTML = `
                <span>${escaparTexto(aluno.numero)}</span>
                <strong class="nome-aluno-remover" title="Dê 2 cliques para remover" style="cursor: pointer;">${escaparTexto(aluno.nome)}</strong>
                <span>${escaparTexto(aluno.turma)}</span>
            `;

            const nomeEl = linha.querySelector('.nome-aluno-remover');
            if (nomeEl) {
                nomeEl.addEventListener('dblclick', () => {
                    removerAlunoPorId(aluno.id);
                });
            }

            listaAlunosEl.appendChild(linha);
        });
    }

    if (btnCadastrar) {
        btnCadastrar.addEventListener('click', cadastrarNovoAluno);
    }

    if (inputNome) {
        inputNome.addEventListener('keydown', e => {
            if (e.key === 'Enter') cadastrarNovoAluno();
        });
    }

    if (inputPesquisa) {
        inputPesquisa.addEventListener('input', renderizarAlunosTurmas);
    }

    if (selectFiltroTurma) {
        selectFiltroTurma.addEventListener('change', renderizarAlunosTurmas);
    }

    cardsTurma.forEach(card => {
        card.addEventListener('click', e => {
            const tituloCard = card.querySelector('.turma-texto h4');
            const nomeTurma = tituloCard ? tituloCard.textContent.trim() : '';
            if (nomeTurma && selectFiltroTurma) {
                e.preventDefault();
                selectFiltroTurma.value = nomeTurma;
                renderizarAlunosTurmas();
                const secaoAlunos = document.getElementById('alunos');
                if (secaoAlunos) {
                    secaoAlunos.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });

    if (btnAdicionarRapido) {
        btnAdicionarRapido.addEventListener('click', () => {
            if (selectTurmaCadastro && selectFiltroTurma && selectFiltroTurma.value) {
                selectTurmaCadastro.value = selectFiltroTurma.value;
            }
            const form = document.querySelector('.formulario-aluno');
            if (form) form.scrollIntoView({ behavior: 'smooth' });
            if (inputNome) inputNome.focus();
        });
    }

    renderizarAlunosTurmas();
}

/* =========================================================
   2. PÁGINA DE PRESENÇAS (presencas.html)
========================================================= */
function iniciarPaginaPresencas() {
    const selectTurma = document.getElementById('turma');
    const selectTrimestre = document.getElementById('trimestre');
    const inputData = document.getElementById('data');
    const selectPeriodo = document.getElementById('periodo');
    const listaSecao = document.querySelector('.lista-presencas');
    const resumoEl = document.querySelector('.resumo-presencas');
    const btnGuardar = document.querySelector('.guardar-presencas');
    const contadorAlunosEl = document.querySelector('.contador-alunos strong');

    if (inputData && !inputData.value) {
        inputData.value = new Date().toISOString().split('T')[0];
    }

    let marcacoes = {};
    let alunosAtuaisNaTela = [];

    function atualizarResumoPresencas() {
        const valores = Object.values(marcacoes);
        const presentes = valores.filter(v => v === 'V').length;
        const faltas = valores.filter(v => v === 'F').length;
        const total = presentes + faltas;

        const camposResumo = document.querySelectorAll('.resumo-item strong');
        if (camposResumo.length >= 3) {
            camposResumo[0].textContent = formatDoisDigitos(presentes);
            camposResumo[1].textContent = formatDoisDigitos(faltas);
            camposResumo[2].textContent = formatDoisDigitos(total);
        }
    }

    function aplicarEstiloBotao(btnAtivo, btnInativo, tipo) {
        btnAtivo.style.opacity = '1';
        btnAtivo.style.transform = 'scale(1.05)';
        btnAtivo.style.boxShadow = tipo === 'V'
            ? '0 0 0 2px #67947B'
            : '0 0 0 2px #B27F99';

        btnInativo.style.opacity = '0.45';
        btnInativo.style.transform = 'scale(1)';
        btnInativo.style.boxShadow = 'none';
    }

    function renderizarListaPresencas() {
        if (!listaSecao || !resumoEl || !selectTurma) return;

        listaSecao.querySelectorAll('.aluno-linha').forEach(el => el.remove());
        marcacoes = {};

        const turmaEscolhida = selectTurma.value.trim();
        alunosAtuaisNaTela = turmaEscolhida
            ? getAlunos().filter(a => a.turma === turmaEscolhida)
            : [];

        if (contadorAlunosEl) {
            contadorAlunosEl.textContent = formatDoisDigitos(alunosAtuaisNaTela.length);
        }

        if (!turmaEscolhida) {
            const msg = document.createElement('div');
            msg.className = 'aluno-linha';
            msg.innerHTML = `
                <span class="numero-aluno">—</span>
                <div class="aluno-info">
                    <strong>Selecione uma turma para carregar os alunos</strong>
                    <small>Escolha a turma na configuração acima</small>
                </div>
                <span></span>
            `;
            listaSecao.insertBefore(msg, resumoEl);
            atualizarResumoPresencas();
            return;
        }

        if (alunosAtuaisNaTela.length === 0) {
            const msg = document.createElement('div');
            msg.className = 'aluno-linha';
            msg.innerHTML = `
                <span class="numero-aluno">—</span>
                <div class="aluno-info">
                    <strong>Nenhum aluno cadastrado em ${escaparTexto(turmaEscolhida)}</strong>
                    <small>Vá ao menu Turmas para adicionar alunos</small>
                </div>
                <span></span>
            `;
            listaSecao.insertBefore(msg, resumoEl);
            atualizarResumoPresencas();
            return;
        }

        alunosAtuaisNaTela.forEach((aluno, idx) => {
            const linha = document.createElement('div');
            linha.className = 'aluno-linha';
            linha.dataset.alunoId = String(aluno.id);

            const numeroExibido = aluno.numero || String(idx + 1).padStart(2, '0');

            linha.innerHTML = `
                <span class="numero-aluno">${escaparTexto(numeroExibido)}</span>
                <div class="aluno-info">
                    <strong>${escaparTexto(aluno.nome)}</strong>
                    <small>${escaparTexto(aluno.turma)}</small>
                </div>
                <div class="marcacao">
                    <button type="button" class="btn-presente" title="Marcar Presença">V</button>
                    <button type="button" class="btn-falta" title="Marcar Falta">F</button>
                </div>
            `;

            const btnV = linha.querySelector('.btn-presente');
            const btnF = linha.querySelector('.btn-falta');

            btnV.addEventListener('click', () => {
                marcacoes[aluno.id] = 'V';
                aplicarEstiloBotao(btnV, btnF, 'V');
                atualizarResumoPresencas();
            });

            btnF.addEventListener('click', () => {
                marcacoes[aluno.id] = 'F';
                aplicarEstiloBotao(btnF, btnV, 'F');
                atualizarResumoPresencas();
            });

            listaSecao.insertBefore(linha, resumoEl);
        });

        atualizarResumoPresencas();
    }

    function guardarPresencasDaAula() {
        const turma = selectTurma ? selectTurma.value.trim() : '';
        const trimestre = selectTrimestre ? selectTrimestre.value.trim() : '';
        const data = inputData ? inputData.value.trim() : '';
        const periodo = selectPeriodo ? selectPeriodo.value.trim() : '';

        if (!turma) {
            alert('Selecione a turma.');
            return;
        }
        if (!trimestre) {
            alert('Selecione o trimestre.');
            return;
        }
        if (!data) {
            alert('Selecione a data da aula.');
            return;
        }
        if (!periodo) {
            alert('Selecione o período.');
            return;
        }
        if (alunosAtuaisNaTela.length === 0) {
            alert('Não há alunos nesta turma para guardar.');
            return;
        }

        const pendentes = alunosAtuaisNaTela.filter(a => !marcacoes[a.id]);
        if (pendentes.length > 0) {
            alert(`Marque V ou F para todos os alunos. Faltam ${pendentes.length}.`);
            return;
        }

        const novoRegisto = {
            id: Date.now(),
            turma,
            trimestre,
            data,
            periodo,
            presencas: alunosAtuaisNaTela.map(aluno => ({
                alunoId: aluno.id,
                nome: aluno.nome,
                numero: aluno.numero,
                estado: marcacoes[aluno.id]
            }))
        };

        const todosRegistos = getRegistos();
        todosRegistos.push(novoRegisto);
        setRegistos(todosRegistos);

        alert('Presenças guardadas com sucesso!');
        renderizarListaPresencas();
    }

    if (selectTurma) {
        selectTurma.addEventListener('change', renderizarListaPresencas);
    }

    if (btnGuardar) {
        btnGuardar.addEventListener('click', guardarPresencasDaAula);
    }

    const params = new URLSearchParams(window.location.search);
    const turmaQuery = params.get('turma');
    if (turmaQuery && selectTurma) {
        const existeOpcao = Array.from(selectTurma.options).some(opt => opt.value === turmaQuery || opt.textContent === turmaQuery);
        if (existeOpcao) {
            selectTurma.value = turmaQuery;
        }
    }

    renderizarListaPresencas();
}

/* =========================================================
   3. PÁGINA DE RELATÓRIOS GERAIS (relatorio.html)
========================================================= */
function iniciarPaginaRelatorios() {
    const filtroTurma = document.getElementById('relatorio-turma');
    const filtroTrimestre = document.getElementById('relatorio-trimestre');

    function atualizarPainelRelatorios() {
        const turmaSel = filtroTurma ? filtroTurma.value.trim() : '';
        const trimestreSel = filtroTrimestre ? filtroTrimestre.value.trim() : '';

        const alunos = getAlunos();
        const registos = getRegistos();

        const alunosFiltrados = turmaSel
            ? alunos.filter(a => a.turma === turmaSel)
            : alunos;

        const registosFiltrados = registos.filter(reg => {
            const okTurma = !turmaSel || reg.turma === turmaSel;
            const okTrimestre = !trimestreSel || reg.trimestre === trimestreSel;
            return okTurma && okTrimestre;
        });

        let somaPresencas = 0;
        let somaFaltas = 0;

        registosFiltrados.forEach(reg => {
            (reg.presencas || []).forEach(item => {
                if (item.estado === 'V') somaPresencas++;
                else if (item.estado === 'F') somaFaltas++;
            });
        });

        const totalMarcacoes = somaPresencas + somaFaltas;
        const taxaGeral = totalMarcacoes > 0
            ? Math.round((somaPresencas / totalMarcacoes) * 100)
            : 0;

        const cardAlunos = document.querySelector('.indicador-alunos h3');
        const cardAulas = document.querySelector('.indicador-aulas h3');
        const cardPresencas = document.querySelector('.indicador-presencas h3');
        const cardFaltas = document.querySelector('.indicador-faltas h3');

        if (cardAlunos) cardAlunos.textContent = formatDoisDigitos(alunosFiltrados.length);
        if (cardAulas) cardAulas.textContent = formatDoisDigitos(registosFiltrados.length);
        if (cardPresencas) cardPresencas.textContent = formatDoisDigitos(somaPresencas);
        if (cardFaltas) cardFaltas.textContent = formatDoisDigitos(somaFaltas);

        const percEl = document.querySelector('.percentagem-assiduidade');
        const barraEl = document.querySelector('.progresso-assiduidade');
        if (percEl) percEl.textContent = `${formatDoisDigitos(taxaGeral)}%`;
        if (barraEl) barraEl.style.width = `${taxaGeral}%`;

        const linhasTurma = document.querySelectorAll('.resumo-turma-relatorio .relatorio-turma-linha');
        linhasTurma.forEach((linha, indice) => {
            const strongNome = linha.querySelector('.relatorio-turma-nome strong');
            const nomeTurma = strongNome ? strongNome.textContent.trim() : TURMAS_PADRAO[indice];
            if (!nomeTurma) return;

            const regsDaTurma = registos.filter(r => {
                const mesmaTurma = r.turma === nomeTurma;
                const mesmoTrim = !trimestreSel || r.trimestre === trimestreSel;
                return mesmaTurma && mesmoTrim;
            });

            let pTurma = 0;
            let fTurma = 0;
            regsDaTurma.forEach(r => {
                (r.presencas || []).forEach(p => {
                    if (p.estado === 'V') pTurma++;
                    else if (p.estado === 'F') fTurma++;
                });
            });

            const totTurma = pTurma + fTurma;
            const percTurma = totTurma > 0 ? Math.round((pTurma / totTurma) * 100) : 0;

            const spans = linha.querySelectorAll('span');
            if (spans[1]) spans[1].textContent = `Presenças: ${formatDoisDigitos(pTurma)}`;
            if (spans[2]) spans[2].textContent = `Faltas: ${formatDoisDigitos(fTurma)}`;

            const ultimoStrong = linha.querySelector('strong:last-child');
            if (ultimoStrong) ultimoStrong.textContent = `${formatDoisDigitos(percTurma)}%`;
        });

        const secaoHistorico = document.querySelector('.historico-relatorios');
        if (!secaoHistorico) return;

        const caixaVazio = secaoHistorico.querySelector('.historico-vazio');
        secaoHistorico.querySelectorAll('.historico-item-dinamico').forEach(el => el.remove());

        if (registosFiltrados.length === 0) {
            if (caixaVazio) caixaVazio.style.display = 'block';
        } else {
            if (caixaVazio) caixaVazio.style.display = 'none';

            [...registosFiltrados].reverse().forEach(reg => {
                const listaP = reg.presencas || [];
                const pQtd = listaP.filter(x => x.estado === 'V').length;
                const fQtd = listaP.filter(x => x.estado === 'F').length;
                const totQtd = pQtd + fQtd;
                const percAula = totQtd > 0 ? Math.round((pQtd / totQtd) * 100) : 0;

                const item = document.createElement('div');
                item.className = 'relatorio-turma-linha historico-item-dinamico';
                item.innerHTML = `
                    <div class="relatorio-turma-nome">
                        <strong>${escaparTexto(reg.turma)}</strong>
                    </div>
                    <span>${escaparTexto(reg.data)} · ${escaparTexto(reg.periodo)} (${escaparTexto(reg.trimestre)})</span>
                    <span>V: ${formatDoisDigitos(pQtd)} | F: ${formatDoisDigitos(fQtd)}</span>
                    <strong>${formatDoisDigitos(percAula)}%</strong>
                `;
                secaoHistorico.appendChild(item);
            });
        }
    }

    if (filtroTurma) filtroTurma.addEventListener('change', atualizarPainelRelatorios);
    if (filtroTrimestre) filtroTrimestre.addEventListener('change', atualizarPainelRelatorios);

    atualizarPainelRelatorios();
}

/* =========================================================
   4. RELATÓRIOS INDIVIDUAIS (relatorios-individuais.html)
========================================================= */
function abrirTurmaIndividual(nomeTurma) {
    const secaoAlunos = document.getElementById('alunos-turma-individual');
    const secaoFicha = document.getElementById('ficha-academica-individual');

    if (!secaoAlunos) return;

    if (secaoFicha) {
        secaoFicha.style.display = 'none';
        secaoFicha.innerHTML = '';
    }

    secaoAlunos.style.display = 'block';

    const alunosTurma = getAlunos().filter(a => a.turma === nomeTurma);

    if (alunosTurma.length === 0) {
        secaoAlunos.innerHTML = `
            <div class="cabecalho-lista-alunos">
                <h3>Turma de ${escaparTexto(nomeTurma)}</h3>
            </div>
            <p class="mensagem-sem-alunos">Nenhum aluno encontrado nesta turma.</p>
        `;
        return;
    }

    let html = `
        <div class="cabecalho-lista-alunos">
            <h3>Alunos de ${escaparTexto(nomeTurma)}</h3>
            <p style="color:#a5a5b5; font-size:13px; margin-top:5px;">
                Selecione um aluno para consultar a ficha académica individual.
            </p>
        </div>
        <div class="lista-alunos-individual">
    `;

    alunosTurma.forEach(aluno => {
        const inicial = aluno.nome ? aluno.nome.trim().charAt(0).toUpperCase() : 'A';
        html += `
            <div class="aluno-card-individual" style="cursor:pointer;" onclick="abrirFichaIndividual(${Number(aluno.id)})">
                <div class="aluno-avatar-individual">${escaparTexto(inicial)}</div>
                <div class="dados-aluno-individual">
                    <h3>${escaparTexto(aluno.nome)}</h3>
                    <p>N.º ${escaparTexto(aluno.numero)} · ${escaparTexto(aluno.turma)}</p>
                </div>
                <span class="seta">→</span>
            </div>
        `;
    });

    html += `</div>`;
    secaoAlunos.innerHTML = html;
    secaoAlunos.scrollIntoView({ behavior: 'smooth' });
}

function abrirFichaIndividual(alunoId) {
    const secaoFicha = document.getElementById('ficha-academica-individual');
    if (!secaoFicha) return;

    const aluno = getAlunos().find(a => Number(a.id) === Number(alunoId));
    if (!aluno) return;

    secaoFicha.style.display = 'block';

    const registosTurma = getRegistos().filter(r => r.turma === aluno.turma);
    let presencas = 0;
    let faltas = 0;
    let historicoHtml = '';

    [...registosTurma].reverse().forEach(reg => {
        const regAluno = (reg.presencas || []).find(p => Number(p.alunoId) === Number(aluno.id));
        if (regAluno) {
            const presente = regAluno.estado === 'V';
            if (presente) presencas++;
            else faltas++;

            historicoHtml += `
                <div class="linha-historico-individual">
                    <div>
                        <strong>${escaparTexto(reg.data)} · ${escaparTexto(reg.periodo)}</strong>
                        <p>${escaparTexto(reg.trimestre)}</p>
                    </div>
                    <span class="${presente ? 'estado-presente' : 'estado-falta'}">
                        ${presente ? 'Presente (V)' : 'Falta (F)'}
                    </span>
                </div>
            `;
        }
    });

    const totalAulas = presencas + faltas;
    const assiduidade = totalAulas > 0 ? Math.round((presencas / totalAulas) * 100) : 0;
    const inicial = aluno.nome ? aluno.nome.trim().charAt(0).toUpperCase() : 'A';

    secaoFicha.innerHTML = `
        <div class="ficha-aluno-individual">
            <div class="ficha-cabecalho">
                <div class="ficha-avatar">${escaparTexto(inicial)}</div>
                <div>
                    <span class="etiqueta-individual">FICHA ACADÉMICA</span>
                    <h2>${escaparTexto(aluno.nome)}</h2>
                    <p>Turma: ${escaparTexto(aluno.turma)} · N.º ${escaparTexto(aluno.numero)}</p>
                </div>
            </div>

            <div class="ficha-indicadores">
                <div class="indicador-individual">
                    <span>Aulas</span>
                    <h3>${formatDoisDigitos(totalAulas)}</h3>
                </div>
                <div class="indicador-individual">
                    <span>Presenças</span>
                    <h3>${formatDoisDigitos(presencas)}</h3>
                </div>
                <div class="indicador-individual">
                    <span>Faltas</span>
                    <h3>${formatDoisDigitos(faltas)}</h3>
                </div>
                <div class="indicador-individual">
                    <span>Assiduidade</span>
                    <h3>${formatDoisDigitos(assiduidade)}%</h3>
                </div>
            </div>

            <div class="historico-individual">
                <h3>Histórico individual</h3>
                <div id="lista-historico-individual">
                    ${historicoHtml || '<p>Ainda não existem registos de aulas para este aluno.</p>'}
                </div>
            </div>
        </div>
    `;

    secaoFicha.scrollIntoView({ behavior: 'smooth' });
}